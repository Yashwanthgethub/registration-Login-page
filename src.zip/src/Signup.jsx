import React, { useState } from 'react';
import { Link } from "react-router-dom"; // Import the Link component
import axios from 'axios';
import { useNavigate}from "react-router-dom"
function Signup() {
    const [name, setname]=useState()
    const [email, setEmail]=useState()
    const [password, setPassword]=useState()
    const navigate = useNavigate()
    const handleSubmit = (e) => {
        e.preventDefault()
        axios.post('http://localhost:3001/register', {name, email,password})
        .then(result=>{console.log(result)
            navigate('/Login')
        })
        .catch(err=>console.log(err))
    }
  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
      <div style={{ width: '400px', padding: '20px', border: '1px solid #ccc', borderRadius: '5px', backgroundColor: '#fff' }}>
        <h2 style={{ textAlign: 'center', marginBottom: '20px' }}>Sign Up</h2>
        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: '20px' }}>
            <label htmlFor="name">Your Name</label>
            <input type="text" className="form-control" id="name" value={name} onChange={(e)=>setname(e.target.value)} placeholder="Enter your name" required />
          </div>
          <div style={{ marginBottom: '20px' }}>
            <label htmlFor="email">Your Email</label>
            <input type="email" className="form-control" id="email" value={email} onChange={(e)=>setEmail(e.target.value)} placeholder="Enter your email" required />
          </div>
          <div style={{ marginBottom: '20px' }}>
            <label htmlFor="password">Password</label>
            <input type="password" className="form-control" id="password" value={password} onChange={(e)=>setPassword(e.target.value)} placeholder="Enter your password" required />
          </div>
          <div style={{ marginBottom: '20px' }}>
            <label htmlFor="confirmPassword">Confirm Password</label>
            <input type="password" className="form-control" id="confirmPassword" placeholder="Confirm your password" required />
          </div>
          <button type="submit" className="btn btn-primary btn-block">Sign Up</button>
        </form>
        <div style={{ textAlign: 'center' }}>
          <p>Already have an account? <Link to="/login">Login</Link></p>
        </div>
      </div>
    </div>
  );
}

export default Signup;
