import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom'; // Import the Link component and useNavigate hook
import axios from 'axios';

function Login() {
  const [email, setEmail]=useState()
  const [password, setpassword]=useState()
  const navigate = useNavigate()// useNavigate hook to navigate programmatically

  const handleSubmit = (e) => {
    e.preventDefault()
    axios.post('http://localhost:3001/login', { email,password})
       .then(result=>{
           console.log(result)
        if(result.data==="Success"){
            navigate('/home')
        }// Redirect to dashboard page after successful login
    }) .catch(err=>console.log(err))
  }
  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
      <div style={{ width: '400px', padding: '20px', border: '1px solid #ccc', borderRadius: '5px', backgroundColor: '#fff' }}>
        <h2 style={{ textAlign: 'center', marginBottom: '20px' }}>Login</h2>
        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: '20px' }}>
            <label htmlFor="email">Your Email</label>
            <input type="email" className="form-control" id="email" value={email} onChange={(e)=>setEmail(e.target.value)} placeholder="Enter your email" required />
          </div>
          <div style={{ marginBottom: '20px' }}>
            <label htmlFor="password">Password</label>
            <input type="password" className="form-control" id="password" value={password} onChange={(e)=>setpassword(e.target.value)}placeholder="Enter your password" required />
          </div>
          <button type="submit" className="btn btn-primary btn-block">Login</button>
        </form>
        <div style={{ textAlign: 'center', marginTop: '20px' }}>
          <p>Dont have an account? <Link to="/signup">Sign Up</Link></p>
        </div>
      </div>
    </div>
  );
}

export default Login;
